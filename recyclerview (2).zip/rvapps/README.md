# jangan lupa:
+ ganti datanya
+ ganti tema sesuai selera
+ ganti layout nya sesuai keinginan
